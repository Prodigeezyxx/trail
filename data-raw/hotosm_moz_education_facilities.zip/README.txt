oex export
==========

Generated:        2026-09-06 19:46:47 UTC
oex version:      0.4.13
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   MOZ
Boundary:         geoBoundaries CGAZ ADM0
Bounding box:     (30.2132, -26.8681, 40.8375, -10.4738)

Dataset:          education_facilities
Format:           GeoJSON (geojson)
Features:         2,091

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-09-06
License:          hdx-odc-odbl
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoJSON is a single-file text format. Consider gpkg for very large layers.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: geofabrik