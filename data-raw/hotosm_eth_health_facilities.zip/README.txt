oex export
==========

Generated:        2026-09-06 17:16:37 UTC
oex version:      0.4.13
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   ETH
Boundary:         geoBoundaries CGAZ ADM0
Bounding box:     (33.0022, 3.4004, 47.9593, 14.8460)

Dataset:          health_facilities
Format:           GeoJSON (geojson)
Features:         1,159

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-09-06
License:          hdx-odc-odbl
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoJSON is a single-file text format. Consider gpkg for very large layers.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: geofabrik